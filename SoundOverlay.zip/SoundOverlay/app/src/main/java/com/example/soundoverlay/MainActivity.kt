package com.example.soundoverlay

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleBtn: Button
    private lateinit var warnText: TextView
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Soundboard"
            textSize = 26f
        })

        statusText = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(statusText)

        toggleBtn = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggleBtn)

        root.addView(Button(this).apply {
            text = "Ruxsatlar sahifasini ochish (Xiaomi)"
            setOnClickListener { openXiaomiPermissions() }
        })

        root.addView(TextView(this).apply {
            text = "Ovoz balandligi"
            textSize = 16f
            setPadding(0, dp(20), 0, 0)
        })
        root.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("volume", 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.edit().putInt("volume", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        root.addView(Button(this).apply {
            text = "Telefon media ovozini maksimal qilish"
            setOnClickListener {
                val am = getSystemService(AudioManager::class.java)
                am.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    AudioManager.FLAG_SHOW_UI
                )
            }
        })

        warnText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFD32F2F.toInt())
            setPadding(0, dp(20), 0, 0)
            gravity = Gravity.START
        }
        root.addView(warnText)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refresh() {
        val running = OverlayService.running
        statusText.text = if (running) "Holati: YOQILGAN" else "Holati: o'chirilgan"
        toggleBtn.text = if (running) "O'CHIRISH" else "YOQISH"

        warnText.text = if (headphonesConnected())
            "⚠ Quloqchin ulangan! Ovoz dinamikdan chiqmaydi va mikrofon eshitmaydi. " +
                    "Quloqchinni ajrating."
        else ""
    }

    private fun headphonesConnected(): Boolean {
        val am = getSystemService(AudioManager::class.java)
        val types = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_USB_HEADSET
        )
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in types }
    }

    private fun onToggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            toggleBtn.postDelayed({ refresh() }, 300)
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Ruxsat kerak")
                .setMessage(
                    "Ikonka o'yin ustida ko'rinishi uchun \"Boshqa ilovalar ustida ko'rsatish\" " +
                            "ruxsatini yoqing. Keyingi sahifada Soundboard ni topib yoqing, " +
                            "so'ng ilovaga qayting."
                )
                .setPositiveButton("Ochish") { _, _ ->
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
                .setNegativeButton("Bekor", null)
                .show()
            return
        }

        startForegroundService(Intent(this, OverlayService::class.java))
        toggleBtn.postDelayed({ refresh() }, 300)

        if (!prefs.getBoolean("xiaomi_asked", false)) {
            prefs.edit().putBoolean("xiaomi_asked", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Xiaomi ruxsatlari")
                .setMessage(
                    "Redmi telefonlarda ikonka o'yin ustida chiqishi uchun quyidagilarni yoqing:\n\n" +
                            "• Fonda ochiladigan oynalarni ko'rsatish (Pop-up windows)\n" +
                            "• Bosh ekran yorliqlari\n" +
                            "• Bloklangan ekranda ko'rsatish"
                )
                .setPositiveButton("Sahifani ochish") { _, _ -> openXiaomiPermissions() }
                .setNegativeButton("Keyinroq", null)
                .show()
        }
    }

    private fun openXiaomiPermissions() {
        try {
            val i = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.permissions.PermissionsEditorActivity"
                )
                putExtra("extra_pkgname", packageName)
            }
            startActivity(i)
        } catch (e: Exception) {
            try {
                val i = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                    setPackage("com.miui.securitycenter")
                    putExtra("extra_pkgname", packageName)
                }
                startActivity(i)
            } catch (e2: Exception) {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }
}
