package com.example.soundoverlay

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.example.soundoverlay.STOP"
        const val ACTION_RELOAD = "com.example.soundoverlay.RELOAD"
    }

    private lateinit var wm: WindowManager
    private lateinit var mainIcon: ImageView
    private lateinit var mainParams: WindowManager.LayoutParams
    private val slotViews = mutableListOf<TextView>()
    private val slotParams = mutableListOf<WindowManager.LayoutParams>()
    private var open = false

    private lateinit var soundPool: SoundPool
    private val soundIds = IntArray(Slots.COUNT)

    private val sizePx by lazy { (56 * resources.displayMetrics.density).toInt() }
    private val gapPx by lazy { (8 * resources.displayMetrics.density).toInt() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_RELOAD -> loadSounds()
        }
        return START_NOT_STICKY
    }

    // Ilova oxirgi ilovalar ro'yxatidan surib tashlansa, ikonka ham yo'qoladi
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            ).build()

        createIcons()
        loadSounds()
    }

    private fun loadSounds() {
        for (i in 0 until Slots.COUNT) {
            if (soundIds[i] != 0) {
                soundPool.unload(soundIds[i])
                soundIds[i] = 0
            }
            val f = Slots.file(this, i)
            if (f.exists()) soundIds[i] = soundPool.load(f.absolutePath, 1)
            slotViews[i].alpha = if (f.exists()) 1f else 0.35f
        }
    }

    private fun layoutParams(x: Int, y: Int) = WindowManager.LayoutParams(
        sizePx, sizePx,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    @Suppress("DEPRECATION")
    private fun screenWidth(): Int {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m.widthPixels
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createIcons() {
        mainIcon = ImageView(this).apply { setImageResource(R.drawable.ic_main) }
        mainParams = layoutParams(40, 300)

        for (i in 0 until Slots.COUNT) {
            val tv = TextView(this).apply {
                text = "${i + 1}"
                gravity = Gravity.CENTER
                textSize = 20f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundResource(R.drawable.bg_slot)
                setOnClickListener { play(i) }
            }
            slotViews.add(tv)
            slotParams.add(layoutParams(0, 0))
        }

        mainIcon.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = mainParams.x; startY = mainParams.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            mainParams.x = startX + dx
                            mainParams.y = startY + dy
                            wm.updateViewLayout(mainIcon, mainParams)
                            if (open) {
                                layoutSlots()
                                for (i in slotViews.indices)
                                    wm.updateViewLayout(slotViews[i], slotParams[i])
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggleSlots()
                }
                return true
            }
        })

        wm.addView(mainIcon, mainParams)
    }

    // Beshta ikonka asosiy ikonka yonida qatorda chiqadi.
    // O'ng tomonga sig'masa, chap tomonga chiqadi.
    private fun layoutSlots() {
        val step = sizePx + gapPx
        val goRight = mainParams.x + step * (Slots.COUNT + 1) <= screenWidth()
        for (i in slotParams.indices) {
            slotParams[i].x = if (goRight) mainParams.x + step * (i + 1)
            else mainParams.x - step * (i + 1)
            slotParams[i].y = mainParams.y
        }
    }

    private fun toggleSlots() {
        if (open) {
            slotViews.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        } else {
            layoutSlots()
            for (i in slotViews.indices) wm.addView(slotViews[i], slotParams[i])
        }
        open = !open
    }

    private fun play(i: Int) {
        val id = soundIds[i]
        if (id == 0) return
        val vol = getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getInt("volume", 100) / 100f
        soundPool.play(id, vol, vol, 1, 0, 1f)
    }

    private fun startAsForeground() {
        val channelId = "overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Soundboard", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_main), "O'chirish", stopPi
        ).build()
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Soundboard ishlayapti")
            .setContentText("Ikonkani o'chirish uchun \"O'chirish\" ni bosing")
            .setSmallIcon(R.drawable.ic_main)
            .setContentIntent(openPi)
            .addAction(stopAction)
            .build()
        startForeground(1, n)
    }

    override fun onDestroy() {
        running = false
        try { if (open) slotViews.forEach { wm.removeView(it) } } catch (_: Exception) {}
        try { wm.removeView(mainIcon) } catch (_: Exception) {}
        soundPool.release()
        super.onDestroy()
    }
}
