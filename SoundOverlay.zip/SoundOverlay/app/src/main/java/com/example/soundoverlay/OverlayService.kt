package com.example.soundoverlay

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.IBinder
import android.view.*
import android.widget.ImageView
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var mainIcon: ImageView
    private lateinit var soundIcon: ImageView
    private lateinit var mainParams: WindowManager.LayoutParams
    private lateinit var soundParams: WindowManager.LayoutParams
    private var soundVisible = false

    private lateinit var soundPool: SoundPool
    private val soundIds = mutableListOf<Int>()

    // Keyin ovoz qo'shish uchun shu ro'yxatga R.raw.xxx qo'shasiz
    private val sounds = listOf(R.raw.sound1)

    private val sizePx by lazy { (56 * resources.displayMetrics.density).toInt() }
    private val gapPx by lazy { (8 * resources.displayMetrics.density).toInt() }

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.example.soundoverlay.STOP"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    // Ilova oxirgi ilovalar ro'yxatidan surib tashlansa, ikonka ham yo'qoladi
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            ).build()
        sounds.forEach { soundIds.add(soundPool.load(this, it, 1)) }

        createIcons()
    }

    private fun layoutParams(x: Int, y: Int) = WindowManager.LayoutParams(
        sizePx, sizePx,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createIcons() {
        mainIcon = ImageView(this).apply { setImageResource(R.drawable.ic_main) }
        soundIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_sound)
            setOnClickListener { playSound() }
        }

        mainParams = layoutParams(40, 300)
        soundParams = layoutParams(mainParams.x + sizePx + gapPx, mainParams.y)

        mainIcon.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = mainParams.x; startY = mainParams.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            mainParams.x = startX + dx
                            mainParams.y = startY + dy
                            wm.updateViewLayout(mainIcon, mainParams)
                            if (soundVisible) updateSoundPosition()
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggleSoundIcon()
                }
                return true
            }
        })

        wm.addView(mainIcon, mainParams)
    }

    private fun updateSoundPosition() {
        soundParams.x = mainParams.x + sizePx + gapPx
        soundParams.y = mainParams.y
        wm.updateViewLayout(soundIcon, soundParams)
    }

    private fun toggleSoundIcon() {
        if (soundVisible) {
            wm.removeView(soundIcon)
        } else {
            updateSoundParamsOnly()
            wm.addView(soundIcon, soundParams)
        }
        soundVisible = !soundVisible
    }

    private fun updateSoundParamsOnly() {
        soundParams.x = mainParams.x + sizePx + gapPx
        soundParams.y = mainParams.y
    }

    private fun playSound() {
        if (soundIds.isEmpty()) return
        // Hozir bitta ovoz; ko'paygach tasodifiy tanlaydi
        val vol = getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getInt("volume", 100) / 100f
        soundPool.play(soundIds.random(), vol, vol, 1, 0, 1f)
    }

    private fun startAsForeground() {
        val channelId = "overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Soundboard", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_main),
            "O'chirish", stopPi
        ).build()
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Soundboard ishlayapti")
            .setContentText("Ikonkani o'chirish uchun \"O'chirish\" ni bosing")
            .setSmallIcon(R.drawable.ic_main)
            .setContentIntent(openPi)
            .addAction(stopAction)
            .build()
        startForeground(1, n)
    }

    override fun onDestroy() {
        running = false
        try { if (soundVisible) wm.removeView(soundIcon) } catch (_: Exception) {}
        try { wm.removeView(mainIcon) } catch (_: Exception) {}
        soundPool.release()
        super.onDestroy()
    }
}
