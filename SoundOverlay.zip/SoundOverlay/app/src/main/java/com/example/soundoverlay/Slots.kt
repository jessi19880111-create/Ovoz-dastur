package com.example.soundoverlay

import android.content.Context
import java.io.File

object Slots {
    const val COUNT = 5

    fun file(ctx: Context, i: Int) = File(ctx.filesDir, "slot$i")

    fun name(ctx: Context, i: Int): String? =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("name$i", null)

    fun setName(ctx: Context, i: Int, name: String?) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .edit().putString("name$i", name).apply()
    }
}
